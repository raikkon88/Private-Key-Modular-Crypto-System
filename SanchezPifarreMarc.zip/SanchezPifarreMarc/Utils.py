def obteNum(text):
# retorna un enter corresponent al desplaçament d'un simple xifrat tipus Cèsar
    desp = input(text)
    return int(desp) 
